import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Created by Hubert on 15/11/9.
 */

public class DatabaseHelper {

    private static final String MYSQL_SERVER_URL = "jdbc:mysql://127.0.0.1:3306/Java_Assignment3?user=root&password=12345";
    public static final String SINGLE_THREAD_TABLE_NAME = "professor_info_java_assignment3";
    public static final String MULTI_TREAD_TABLE_NAME = "professor_info_multithread";



    public void addProfessorToDatabase(Professor2014302580190 professor, String tableName) {

        //guard
        if (!tableName.equals(SINGLE_THREAD_TABLE_NAME) && !tableName.equals(MULTI_TREAD_TABLE_NAME)) {
            return;
        }



        String name = professor.getName();
        String phoneNumber = professor.getPhoneNumber();
        String researchInterests = professor.getResearchInterests();

        String nameWithQuotationMark = "'" + name + "'";
        String phoneNumberWithQuotationMark = "'" + phoneNumber + "'";
        String researchInterestsWithQuotationMark = "'" + researchInterests + "'";

        String values = nameWithQuotationMark + "," + phoneNumberWithQuotationMark + "," + researchInterestsWithQuotationMark;


        Connection connection = null;
        String databaseURL = "jdbc:mysql://127.0.0.1:3306/Java_Assignment3?"
                + "user=root&password=12345&useUnicode=true&characterEncoding=UTF8";
        //String sql = "insert into " + tableName + "(name,phone_number,research_interests) values(" + values + ")";
        String sql = "insert into " + tableName + "(name,phone_number,research_interests) values('" + name + "','" + phoneNumber + "','" + researchInterests + "')";
        System.out.print("=");
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(databaseURL);
            Statement statement = connection.createStatement();
            statement.executeUpdate(sql);

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
//
//        String sql = "insert into " + tableName + "(name,phone_number,research_interests) values('" + name + "','"
//                + phoneNumber + "','" + researchInterests + "')";
//        Connection connection = null;
//        String databaseURL = "jdbc:mysql://127.0.0.1:3306/Java_Assignment3?user=root&password=12345&useUnicode=true&characterEncoding=UTF8";
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            connection = DriverManager.getConnection(databaseURL);
//            Statement statement = connection.createStatement();
//            statement.executeUpdate(sql);
//        } catch (SQLException e) {
//            e.printStackTrace();
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                connection.close();
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        }

    }

    public static void truncateTable(String tableName) {
        //guard
        if (!tableName.equals(SINGLE_THREAD_TABLE_NAME) && !tableName.equals(MULTI_TREAD_TABLE_NAME)) {
            return;
        }

        String sql = "truncate " + tableName;
        Connection connection = null;
        String databaseURL = "jdbc:mysql://127.0.0.1:3306/Java_Assignment3?user=root&password=12345&useUnicode=true&characterEncoding=UTF8";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(databaseURL);
            Statement statement = connection.createStatement();
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

//    public ResultSet runSelect(String sql) {
//        Connection connection = null;
//        PreparedStatement preparedStatement = null;
//        ResultSet resultSet = null;
//        try {
//            connection = getConnection(this.MYSQL_SERVER_URL);
//            preparedStatement = connection.prepareStatement(sql);
//            resultSet = preparedStatement.executeQuery();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                preparedStatement.close();
//                connection.close();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//        return resultSet;
//    }
//
//    public void runUpdate(String sql) {
//        Connection connection = null;
//        PreparedStatement preparedStatement = null;
//        try {
//            connection = getConnection(this.MYSQL_SERVER_URL);
//            preparedStatement = connection.prepareStatement(sql);
//            preparedStatement.executeUpdate();
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                preparedStatement.close();
//                connection.close();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//    }
//
//    public void runUpdate(String sql, Object[] params) {
//        Connection connection = null;
//        PreparedStatement preparedStatement = null;
//        try {
//            connection = getConnection(this.MYSQL_SERVER_URL);
//            preparedStatement = connection.prepareStatement(sql);
//            for (int i = 0; i < params.length; i++) {
//                preparedStatement.setObject(i + 1, params[i]);
//            }
//            preparedStatement.executeUpdate();
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                preparedStatement.close();
//                connection.close();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//    }
}
