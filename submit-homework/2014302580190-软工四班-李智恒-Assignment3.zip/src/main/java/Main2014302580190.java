import java.util.ArrayList;

/**
 * Created by Hubert on 15/11/9.
 */
public class Main2014302580190 {

    public static void main(String[] args) throws Exception {

        String filePath = "./resource/Faculty_List_EECS_at_UC_Berkeley.html";
        ProfessorParser2014302580190 parser = new ProfessorParser2014302580190(filePath);

        //单线程爬虫
        System.out.println("单线程爬虫开始！");
        long startTimeInSingleThread = System.currentTimeMillis();
        parser.parseHtmlInSingleThread();
        ArrayList<Professor2014302580190> professorList = parser.getProfessorList();
        //清空表内容
        DatabaseHelper.truncateTable(DatabaseHelper.SINGLE_THREAD_TABLE_NAME);
        DatabaseHelper databaseHelper = new DatabaseHelper();
        for (Professor2014302580190 professor: professorList) {
            databaseHelper.addProfessorToDatabase(professor, DatabaseHelper.SINGLE_THREAD_TABLE_NAME);
        }
        long endTimeInSingleThread = System.currentTimeMillis();
        long differenceTimeInSingleThread = endTimeInSingleThread - startTimeInSingleThread;
        System.out.println("单线程爬虫结束，耗时：" + differenceTimeInSingleThread + "毫秒");


        //多线程爬虫
        System.out.println("多线程爬虫开始！");
        DatabaseHelper.truncateTable(DatabaseHelper.MULTI_TREAD_TABLE_NAME);
        long startTimeInMultiThread = System.currentTimeMillis();
        parser.parserHTMLInMultiThread();
        while (true) {
            if (Thread.activeCount() < 5) {
                break;
            }
        }
        long endTimeInMultiThread = System.currentTimeMillis();
        long differenceTimeInMultiThread = endTimeInMultiThread - startTimeInMultiThread;
        System.out.println("多线程爬虫结束，耗时：" + differenceTimeInMultiThread + "毫秒");

    }
}
