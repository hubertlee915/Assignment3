import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Hubert on 15/11/13.
 */
public class ParserRunnable2014302580190 implements Runnable {

    Elements tableRows;
    int indexOfTableRow;

    public ParserRunnable2014302580190(Elements tableRows, int indexOfTableRow) {
        this.tableRows = tableRows;
        this.indexOfTableRow = indexOfTableRow;
    }

    public void run() {
        String name = "";
        String phoneNumber = "";
        String researchInterests = "";

        //查找name
        Element element = tableRows.get(indexOfTableRow);
        Element nameElement =  element.getElementsByTag("a").get(0);
        name = nameElement.ownText();


        //查找电话
        int nextRow = indexOfTableRow + 1;
        Element nextRowElement = tableRows.get(nextRow);
        Element phoneNumberElement = nextRowElement.getElementsByTag("td").get(2);
        String mayContainPhoneNumber = phoneNumberElement.ownText();
        Pattern pattern = Pattern.compile("\\D*([2-9]\\d{2})(\\D*)([2-9]\\d{2})(\\D*)(\\d{4})\\D*");
        Matcher matcher = pattern.matcher(mayContainPhoneNumber);
        if (matcher.find()) {
            phoneNumber = matcher.group();
        }


        //查找研究方向
        String href = nameElement.absUrl("href");
        try {
            Document professorDoc = Jsoup.connect(href).get();
            if (professorDoc != null) {
                Elements tempElements = professorDoc.getElementsByClass("tight");
                if (tempElements != null) {
                    Element firstElement = tempElements.first();
                    if (firstElement != null) {
                        researchInterests = firstElement.text();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Professor2014302580190 professor = new Professor2014302580190(name, phoneNumber, researchInterests);

        DatabaseHelper databaseHelper = new DatabaseHelper();
        databaseHelper.addProfessorToDatabase(professor, DatabaseHelper.MULTI_TREAD_TABLE_NAME);
    }
}
