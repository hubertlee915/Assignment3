/**
 * Created by Hubert on 15/11/9.
 */
public class Professor2014302580190 {
    String name;
    String phoneNumber;
    String researchInterests;

    public Professor2014302580190(String name, String phoneNumber, String researchInterests) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.researchInterests = researchInterests;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getName() {
        return name;
    }

    public String getResearchInterests() {
        return researchInterests;
    }

    @Override
    public String toString() {
        return name + " " + phoneNumber + " " + researchInterests;
    }
}
