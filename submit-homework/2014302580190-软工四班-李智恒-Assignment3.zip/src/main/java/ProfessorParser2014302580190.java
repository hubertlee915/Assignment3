import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Hubert on 15/11/9.
 */
public class ProfessorParser2014302580190 {
    public Elements trs;
    public int rowNumber;
    Document doc;
    ArrayList<Professor2014302580190> professorList;

    public ProfessorParser2014302580190(String filePath) {
        try {
            this.doc = Jsoup.parse(new File(filePath), "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.professorList = new ArrayList<Professor2014302580190>();
        this.trs = doc.getElementsByTag("tbody").get(0).getElementsByTag("tr");
        this.rowNumber = trs.size();
    }

    public void parseHtmlInSingleThread() {

        for (int i = 1; i < rowNumber; i+=3) {
            if (i > rowNumber) {
                break;
            }

            String name = "";
            String phoneNumber = "";
            String researchInterests = "";

            //查找name
            Element element = trs.get(i);
            Element nameElement =  element.getElementsByTag("a").get(0);
            name = nameElement.ownText();


            //查找电话
            int nextRow = i + 1;
            Element nextRowElement = trs.get(nextRow);
            Element phoneNumberElement = nextRowElement.getElementsByTag("td").get(2);
            String mayContainPhoneNumber = phoneNumberElement.ownText();
            Pattern pattern = Pattern.compile("\\D*([2-9]\\d{2})(\\D*)([2-9]\\d{2})(\\D*)(\\d{4})\\D*");
            Matcher matcher = pattern.matcher(mayContainPhoneNumber);
            if (matcher.find()) {
                phoneNumber = matcher.group();
            }


            //查找研究方向
            String href = nameElement.absUrl("href");
            try {
                Document professorDoc = Jsoup.connect(href).get();
                if (professorDoc != null) {
                    Elements tempElements = professorDoc.getElementsByClass("tight");
                    if (tempElements != null) {
                        Element firstElement = tempElements.first();
                        if (firstElement != null) {
                            researchInterests = firstElement.text();
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            Professor2014302580190 professor = new Professor2014302580190(name, phoneNumber, researchInterests);
            professorList.add(professor);

        }


//        Elements tableRows = doc.getElementsByTag("tbody").first().getElementsByTag("tr");
//        for (int i = 1; i < tableRows.size(); i++) {
//            Element tableRow = tableRows.get(i);
//            Elements tableDetails = tableRow.getElementsByTag("td");
//            String name = tableDetails.get(0).getElementsByTag("a").first().ownText();
//            if (name.equals("王雪红")) {
//                continue;
//            }
//            String researchInterests = tableDetails.get(2).ownText();
//            String email = tableDetails.get(4).getElementsByTag("a").first().ownText();
//            //网站信息有误，去掉重复的@符号
//            String newEmail = email.replaceFirst("@", "");
//            Professor2014302580190 professor = new Professor2014302580190(name, newEmail, researchInterests);
//            professorList.add(professor);
//        }
    }


    public void parserHTMLInMultiThread() {
        ExecutorService executorService = Executors.newFixedThreadPool(8);

        for (int i = 1; i < rowNumber; i+=3) {
            ParserRunnable2014302580190 parserRunnable = new ParserRunnable2014302580190(this.trs, i);
            executorService.execute(parserRunnable);
        }

        executorService.shutdown();
    }

    public ArrayList<Professor2014302580190> getProfessorList() {
        return professorList;
    }
}
